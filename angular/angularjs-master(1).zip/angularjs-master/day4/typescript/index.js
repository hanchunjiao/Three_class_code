console.log(1);
var bool = false;
var num = 1;
var str = "abc";
var arr = [0, 1, 2];
var tuple = ["abc", false];
var any = 1;
var func = function (a, b) {
    //return a+b
};
var add = function (a, b) {
};
var bo5 = 1;
func(1, 2);
var people = /** @class */ (function () {
    function people(name) {
        this.name = name;
        this.skill = "ps";
    }
    people.prototype.getName = function () {
        return this.name;
    };
    return people;
}());
var obj = {
    skill: "ps",
    bool: true,
    arr: ["a", "b", "c"]
};
