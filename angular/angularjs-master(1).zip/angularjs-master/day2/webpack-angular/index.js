import angular from "angular";
const app = angular.module("ngApp", []);

app.controller("indexCtrl", ($scope) => {
  $scope.name = "qd"
  $scope.skill = "ps"
})
