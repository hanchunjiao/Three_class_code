(function() {
  var app = angular.module("ngApp", [
    "ui.router",
    "router",
    "services",
    "directives",
    "filters",
    "components",
    "controllers"
  ]);
})()
