var directives = angular.module("directives", []);
// 指令
directives.directive("ngColor", function() {
  return {
    link: function(scope, ele, attr) {}
  }
})
