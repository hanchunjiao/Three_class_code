var controllers = angular.module("controllers", []);
// 控制器
controllers.controller("indexCtrl", function($scope) {})
